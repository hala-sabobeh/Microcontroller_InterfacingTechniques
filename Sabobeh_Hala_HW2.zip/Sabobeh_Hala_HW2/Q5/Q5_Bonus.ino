
// Q5 — Traffic-Light Controller with Pedestrian Crossing


#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

// ── BONUS: 7-segment PROGMEM table ───────────────────────────

static const uint8_t SEG7[] PROGMEM = {
    0x3F, // 0
    0x06, // 1
    0x5B, // 2
    0x4F, // 3
    0x66, // 4
    0x6D, // 5
    0x7D, // 6
    0x07, // 7
    0x7F, // 8
    0x6F  // 9
};

static uint8_t seg7_encode(uint8_t d) {
    if (d > 9) d = 9;
    return pgm_read_byte(&SEG7[d]);
}

// ── LED bitmasks ─────────────────────────────────────────────
#define RED_BIT      (1 << PB0)
#define YELLOW_BIT   (1 << PB1)
#define GREEN_BIT    (1 << PB2)
#define PED_BIT      (1 << PB3)
#define TRAFFIC_MASK (RED_BIT | YELLOW_BIT | GREEN_BIT | PED_BIT)

// ── Phase durations ──────────────────────────────────────────
#define DUR_GREEN   5000UL
#define DUR_YELLOW  2000UL
#define DUR_RED     5000UL
#define DUR_PED     4000UL

// ── State enum + globals ──────────────────────────────────────
enum State { GREEN_PHASE, YELLOW_PHASE, RED_PHASE, PED_CROSS };
State    state      = GREEN_PHASE;
uint32_t stateStart = 0;

volatile bool pedRequest = false;

uint32_t lcdPrev     = 0;
uint32_t blinkPrev   = 0;
bool     blinkActive = false;

// ── Forward declarations ──────────────────────────────────────
void changeState(State next);
void updateCountdown();
void startPedBlink();
void stopPedBlink();

// ── INT0 ISR ─────────────────────────────────────────────────
ISR(INT0_vect) {
    pedRequest = true;
}

// ════════════════════════════════════════════════════════════
//  LCD DRIVER (Q1 bare-metal)
// ════════════════════════════════════════════════════════════
#define DATA_MASK  0xF0
#define RS_BIT     (1 << PB4)
#define EN_BIT     (1 << PB5)

static void lcd_wait_us(uint16_t us) {
    uint32_t start = micros();
    while ((uint32_t)(micros() - start) < (uint32_t)us);
}

static void lcd_pulse_en() {
    PORTB |=  EN_BIT;
    __asm__ __volatile__("nop\n nop\n nop\n nop\n");
    PORTB &= ~EN_BIT;
}

static void lcd_send_nibble(uint8_t nib) {
    PORTD = (PORTD & ~DATA_MASK) | (nib & DATA_MASK);
    lcd_pulse_en();
}

static void lcd_send(uint8_t byte, uint8_t rs) {
    if (rs) PORTB |=  RS_BIT;
    else    PORTB &= ~RS_BIT;
    lcd_send_nibble( byte & 0xF0);
    lcd_send_nibble((byte << 4) & 0xF0);
    lcd_wait_us(50);
}

void lcd_command(uint8_t cmd) { lcd_send(cmd, 0); }
void lcd_data   (uint8_t b  ) { lcd_send(b,   1); }

void lcd_setCursor(uint8_t col, uint8_t row) {
    lcd_command(0x80 | ((row ? 0x40 : 0x00) + col));
}

void lcd_print(const char *s) { while (*s) lcd_data(*s++); }

void lcd_printUInt(uint16_t n) {
    char buf[6]; int8_t i = 0;
    if (!n) { lcd_data('0'); return; }
    while (n) { buf[i++] = '0' + (n % 10); n /= 10; }
    for (int8_t j = i - 1; j >= 0; j--) lcd_data(buf[j]);
}

void lcd_init() {
    DDRB |= RS_BIT | EN_BIT;
    DDRD |= DATA_MASK;
    PORTB &= ~(RS_BIT | EN_BIT);
    lcd_wait_us(50000);
    PORTB &= ~RS_BIT;
    lcd_send_nibble(0x30); lcd_wait_us(4200);
    lcd_send_nibble(0x30); lcd_wait_us(150);
    lcd_send_nibble(0x30); lcd_wait_us(150);
    lcd_send_nibble(0x20); lcd_wait_us(150);
    lcd_command(0x28);
    lcd_command(0x0C);
    lcd_command(0x06);
    lcd_command(0x01);
    lcd_wait_us(2000);
}

// ════════════════════════════════════════════════════════════
//  LCD ROW 1 — countdown via PROGMEM 7-seg table (BONUS)
//  Displays: "T:Xs NNh"
//    X  = seconds remaining
//    NN = 7-segment hex byte from PROGMEM table
// ════════════════════════════════════════════════════════════
void updateCountdown() {
    uint32_t elapsed = millis() - stateStart;
    uint32_t total;
    switch (state) {
        case GREEN_PHASE:  total = DUR_GREEN;  break;
        case YELLOW_PHASE: total = DUR_YELLOW; break;
        case RED_PHASE:    total = DUR_RED;    break;
        default:           total = DUR_PED;    break;
    }
    uint8_t rem = (uint8_t)((elapsed < total) ? (total - elapsed) / 1000UL : 0);
    uint8_t segByte = seg7_encode(rem);
    uint8_t hi = (segByte >> 4) & 0x0F;
    uint8_t lo =  segByte & 0x0F;

    lcd_setCursor(0, 1);
    lcd_print("T:");
    lcd_data('0' + rem);
    lcd_print("s ");
    lcd_data(hi < 10 ? '0' + hi : 'A' + hi - 10);
    lcd_data(lo < 10 ? '0' + lo : 'A' + lo - 10);
    lcd_print("h  ");
}

// ════════════════════════════════════════════════════════════
//  Pedestrian LED blink
// ════════════════════════════════════════════════════════════
void startPedBlink() {
    blinkActive = true;
    blinkPrev   = millis();
    PORTB &= ~PED_BIT;
}

void stopPedBlink() {
    blinkActive = false;
    PORTB &= ~PED_BIT;
}

// ════════════════════════════════════════════════════════════
//  State transition
// ════════════════════════════════════════════════════════════
void changeState(State next) {
    stopPedBlink();
    state      = next;
    stateStart = millis();
    lcdPrev    = millis() - 1000;

    lcd_setCursor(0, 0);
    switch (next) {
        case GREEN_PHASE:
            PORTB = (PORTB & ~TRAFFIC_MASK) | GREEN_BIT;
            lcd_print("GO              ");
            break;
        case YELLOW_PHASE:
            PORTB = (PORTB & ~TRAFFIC_MASK) | YELLOW_BIT;
            lcd_print("SLOW            ");
            break;
        case RED_PHASE:
            PORTB = (PORTB & ~TRAFFIC_MASK) | RED_BIT;
            lcd_print("STOP            ");
            pedRequest = false;
            break;
        case PED_CROSS:
            PORTB = (PORTB & ~TRAFFIC_MASK) | RED_BIT;
            lcd_print("CROSS           ");
            pedRequest = false;
            startPedBlink();
            break;
    }
    updateCountdown();
}

// ════════════════════════════════════════════════════════════
//  SETUP
// ════════════════════════════════════════════════════════════
void setup() {
    DDRB  |=  TRAFFIC_MASK;
    PORTB &= ~TRAFFIC_MASK;

    DDRD  &= ~(1 << PD2);
    PORTD |=  (1 << PD2);

    EICRA |=  (1 << ISC01);
    EICRA &= ~(1 << ISC00);
    EIMSK |=  (1 << INT0);
    sei();

    lcd_init();
    changeState(GREEN_PHASE);
}

// ════════════════════════════════════════════════════════════
//  MAIN LOOP
// ════════════════════════════════════════════════════════════
void loop() {
    uint32_t now     = millis();
    uint32_t elapsed = now - stateStart;

    if (now - lcdPrev >= 1000) {
        lcdPrev = now;
        updateCountdown();
    }

    if (blinkActive && (now - blinkPrev >= 250)) {
        blinkPrev = now;
        PORTB ^= PED_BIT;
    }

    switch (state) {
        case GREEN_PHASE:
            if (elapsed >= DUR_GREEN) {
                if (pedRequest) {
                    pedRequest = false;
                    changeState(PED_CROSS);
                } else {
                    changeState(YELLOW_PHASE);
                }
            }
            break;
        case YELLOW_PHASE:
            if (elapsed >= DUR_YELLOW) changeState(RED_PHASE);
            break;
        case RED_PHASE:
            pedRequest = false;
            if (elapsed >= DUR_RED) changeState(GREEN_PHASE);
            break;
        case PED_CROSS:
            pedRequest = false;
            if (elapsed >= DUR_PED) changeState(GREEN_PHASE);
            break;
    }
}