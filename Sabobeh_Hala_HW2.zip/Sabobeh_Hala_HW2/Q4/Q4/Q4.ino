// ============================================================
// Q4 — Hardware Interrupts: Part B (Register-Level) + Bonus
// Course: Microcontroller Systems (ENCS4380)
// Platform: Arduino Uno (ATmega328P)
// LCD: RS=D12(PB4), EN=D13(PB5), Data=PD4-PD7
// Button 1 → D2 (INT0) — increment count
// Button 2 → D3 (INT1) — reset count
// Button 3 → A0 (PC0)  — BONUS: pause/resume toggle
// Approach: Direct AVR registers EICRA/EIMSK, ISR() macros
// ============================================================

// ── LCD driver (RS=D12/PB4, EN=D13/PB5) ─────────────────────
#define DATA_MASK 0xF0
#define RS_BIT (1<<PB4)
#define EN_BIT (1<<PB5)

void lcd_pulse_en() {
    PORTB |= EN_BIT;
    __asm__ __volatile__("nop\n nop\n nop\n nop\n");
    PORTB &= ~EN_BIT;
}

void lcd_send_nibble(uint8_t nib) {
    PORTD = (PORTD & ~DATA_MASK) | (nib & DATA_MASK);
    lcd_pulse_en();
}

void lcd_send(uint8_t byte, uint8_t rs) {
    if (rs) PORTB |= RS_BIT;
    else    PORTB &= ~RS_BIT;
    lcd_send_nibble(byte & 0xF0);
    lcd_send_nibble((byte << 4) & 0xF0);
    uint32_t t = micros();
    while (micros() - t < 50);
}

void lcd_command(uint8_t cmd) { lcd_send(cmd, 0); }
void lcd_data(uint8_t b)      { lcd_send(b,   1); }

void lcd_setCursor(uint8_t col, uint8_t row) {
    uint8_t addr = (row == 0) ? 0x00 : 0x40;
    lcd_command(0x80 | (addr + col));
}

void lcd_print(const char *s) {
    while (*s) lcd_data(*s++);
}

void lcd_printInt(uint16_t n) {
    char buf[6];
    uint8_t i = 0;
    if (n == 0) { lcd_data('0'); return; }
    while (n > 0) { buf[i++] = '0' + (n % 10); n /= 10; }
    for (int8_t j = i-1; j >= 0; j--) lcd_data(buf[j]);
}

void lcd_init() {
    DDRB |= RS_BIT | EN_BIT;
    DDRD |= DATA_MASK;
    uint32_t t = micros();
    while (micros() - t < 50000);
    PORTB &= ~RS_BIT;
    lcd_send_nibble(0x30);
    t = micros(); while (micros() - t < 4200);
    lcd_send_nibble(0x30);
    t = micros(); while (micros() - t < 150);
    lcd_send_nibble(0x30);
    t = micros(); while (micros() - t < 150);
    lcd_send_nibble(0x20);
    t = micros(); while (micros() - t < 150);
    lcd_command(0x28);
    lcd_command(0x0C);
    lcd_command(0x06);
    PORTB &= ~RS_BIT;
    lcd_send_nibble(0x00 & 0xF0);
    lcd_send_nibble((0x01 << 4) & 0xF0);
    t = micros(); while (micros() - t < 2000);
}

// ── Interrupt state ──────────────────────────────────────────
volatile uint16_t count        = 0;
volatile uint32_t lastPress0MS = 0;  // separate debounce for Button 1
volatile uint32_t lastPress1MS = 0;  // separate debounce for Button 2
volatile bool     changed      = false;

// BONUS: pause flag (checked inside ISR)
bool paused = false;

// ── Part B — Register-level ISRs (no attachInterrupt) ────────
// EICRA controls edge: ISC01=1,ISC00=0 → falling edge on INT0
//                      ISC11=1,ISC10=0 → falling edge on INT1
// EIMSK enables the interrupt lines: INT0 and INT1
ISR(INT0_vect) {
    uint32_t now = millis();
    if (now - lastPress0MS >= 300) {  // 100ms debounce
        lastPress0MS = now;
        if (!paused) {
            count++;
            changed = true;
        }
    }
}

ISR(INT1_vect) {
    uint32_t now = millis();
    if (now - lastPress1MS >= 100) {  // 100ms debounce
        lastPress1MS = now;
        if (!paused) {
            count = 0;
            changed = true;
        }
    }
}

// ── Button 3 (pause) debounce state ──────────────────────────
uint32_t lastPausePress = 0;
uint8_t  btn3Prev       = 1;

// ── Setup ────────────────────────────────────────────────────
void setup() {
    Serial.begin(9600);

    // Button 1 (D2/INT0) and Button 2 (D3/INT1): input + pull-up
    DDRD  &= ~((1<<PD2) | (1<<PD3));
    PORTD |=  ((1<<PD2) | (1<<PD3));

    // BONUS Button 3 on A0 (PC0): input + pull-up
    DDRC  &= ~(1<<PC0);
    PORTC |=  (1<<PC0);

    // Part B — configure INT0 falling edge via EICRA
    // ISC01=1, ISC00=0 → falling edge
    EICRA |=  (1 << ISC01);
    EICRA &= ~(1 << ISC00);

    // Part B — configure INT1 falling edge via EICRA
    // ISC11=1, ISC10=0 → falling edge
    EICRA |=  (1 << ISC11);
    EICRA &= ~(1 << ISC10);

    // Part B — enable INT0 and INT1 via EIMSK
    EIMSK |= (1 << INT0) | (1 << INT1);

    // Enable global interrupts
    sei();

    lcd_init();

    lcd_setCursor(0, 0);
    lcd_print("Count: 0        ");
    lcd_setCursor(0, 1);
    lcd_print("BTN1=+ BTN2=RST ");
}

// ── Loop ─────────────────────────────────────────────────────
void loop() {

    // BONUS: poll Button 3 (A0/PC0) for pause toggle
    uint8_t btn3Now = (PINC >> PC0) & 1;
    uint32_t now = millis();

    if (btn3Now == 0 && btn3Prev == 1 && (now - lastPausePress >= 100)) {
        paused = !paused;
        lastPausePress = now;

        lcd_setCursor(0, 1);
        if (paused)
            lcd_print("*** PAUSED ***  ");
        else
            lcd_print("BTN1=+ BTN2=RST ");

        Serial.println(paused ? "PAUSED" : "RESUMED");
    }
    btn3Prev = btn3Now;

    // Update display when count changes (flag set in ISR)
    if (changed) {
        cli();                   // disable interrupts briefly
        uint16_t snap = count;   // safe snapshot of volatile variable
        changed = false;
        sei();                   // re-enable interrupts

        lcd_setCursor(0, 0);
        lcd_print("Count: ");
        lcd_printInt(snap);
        lcd_print("        ");

        Serial.print("Counter: ");
        Serial.println(snap);
    }
}