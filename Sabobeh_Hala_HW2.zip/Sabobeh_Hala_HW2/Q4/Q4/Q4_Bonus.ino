
// ── LCD driver (RS=D12/PB4, EN=D13/PB5) ─────────────────────
#define DATA_MASK 0xF0
#define RS_BIT (1<<PB4)
#define EN_BIT (1<<PB5)

void lcd_pulse_en() {
    PORTB |= EN_BIT;
    __asm__ __volatile__("nop\n nop\n nop\n nop\n");
    PORTB &= ~EN_BIT;
}

void lcd_send_nibble(uint8_t nib) {
    PORTD = (PORTD & ~DATA_MASK) | (nib & DATA_MASK);
    lcd_pulse_en();
}

void lcd_send(uint8_t byte, uint8_t rs) {
    if (rs) PORTB |= RS_BIT;
    else    PORTB &= ~RS_BIT;
    lcd_send_nibble(byte & 0xF0);
    lcd_send_nibble((byte << 4) & 0xF0);
    uint32_t t = micros();
    while (micros() - t < 50);
}

void lcd_command(uint8_t cmd) { lcd_send(cmd, 0); }
void lcd_data(uint8_t b)      { lcd_send(b,   1); }

void lcd_setCursor(uint8_t col, uint8_t row) {
    uint8_t addr = (row == 0) ? 0x00 : 0x40;
    lcd_command(0x80 | (addr + col));
}

void lcd_print(const char *s) {
    while (*s) lcd_data(*s++);
}

void lcd_printInt(uint16_t n) {
    char buf[6];
    uint8_t i = 0;
    if (n == 0) { lcd_data('0'); return; }
    while (n > 0) { buf[i++] = '0' + (n % 10); n /= 10; }
    for (int8_t j = i-1; j >= 0; j--) lcd_data(buf[j]);
}

void lcd_init() {
    DDRB |= RS_BIT | EN_BIT;
    DDRD |= DATA_MASK;
    uint32_t t = micros();
    while (micros() - t < 50000);
    PORTB &= ~RS_BIT;
    lcd_send_nibble(0x30);
    t = micros(); while (micros() - t < 4200);
    lcd_send_nibble(0x30);
    t = micros(); while (micros() - t < 150);
    lcd_send_nibble(0x30);
    t = micros(); while (micros() - t < 150);
    lcd_send_nibble(0x20);
    t = micros(); while (micros() - t < 150);
    lcd_command(0x28);
    lcd_command(0x0C);
    lcd_command(0x06);
    PORTB &= ~RS_BIT;
    lcd_send_nibble(0x00 & 0xF0);
    lcd_send_nibble((0x01 << 4) & 0xF0);
    t = micros(); while (micros() - t < 2000);
}

// ── Interrupt state ──────────────────────────────────────────
volatile uint16_t count        = 0;
volatile uint32_t lastPress0MS = 0;  // separate debounce for Button 1
volatile uint32_t lastPress1MS = 0;  // separate debounce for Button 2
volatile bool     changed      = false;

// BONUS: pause flag
bool paused = false;

// ── ISRs ─────────────────────────────────────────────────────
ISR(INT0_vect) {
    uint32_t now = millis();
    if (now - lastPress0MS >= 100) {  // 100ms debounce — more reliable
        lastPress0MS = now;           // update FIRST before any logic
        if (!paused) {
            count++;
            changed = true;
        }
    }
}

ISR(INT1_vect) {
    uint32_t now = millis();
    if (now - lastPress1MS >= 100) {  // 100ms debounce — more reliable
        lastPress1MS = now;           // update FIRST before any logic
        if (!paused) {
            count = 0;
            changed = true;
        }
    }
}

// ── Button 3 debounce state ───────────────────────────────────
uint32_t lastPausePress = 0;
uint8_t  btn3Prev       = 1;

// ── Setup ────────────────────────────────────────────────────
void setup() {
    Serial.begin(9600);

    // Button 1 (D2/INT0) and Button 2 (D3/INT1): input + pull-up
    DDRD  &= ~((1<<PD2) | (1<<PD3));
    PORTD |=  ((1<<PD2) | (1<<PD3));

    // BONUS Button 3 on A0 (PC0): input + pull-up
    DDRC  &= ~(1<<PC0);
    PORTC |=  (1<<PC0);

    // INT0 falling edge
    EICRA |=  (1 << ISC01);
    EICRA &= ~(1 << ISC00);

    // INT1 falling edge
    EICRA |=  (1 << ISC11);
    EICRA &= ~(1 << ISC10);

    // Enable INT0 and INT1
    EIMSK |= (1 << INT0) | (1 << INT1);

    sei();

    // LCD last
    lcd_init();

    // Initial display
    lcd_setCursor(0, 0);
    lcd_print("Count: 0        ");
    lcd_setCursor(0, 1);
    lcd_print("BTN1=+ BTN2=RST ");
}

// ── Loop ─────────────────────────────────────────────────────
void loop() {

    // ── BONUS: poll Button 3 (A0/PC0) for pause toggle ───────
    uint8_t btn3Now = (PINC >> PC0) & 1;
    uint32_t now = millis();

    if (btn3Now == 0 && btn3Prev == 1 && (now - lastPausePress >= 100)) {
        paused = !paused;
        lastPausePress = now;

        lcd_setCursor(0, 1);
        if (paused)
            lcd_print("*** PAUSED ***  ");
        else
            lcd_print("BTN1=+ BTN2=RST ");

        Serial.println(paused ? "PAUSED" : "RESUMED");
    }
    btn3Prev = btn3Now;

    // ── Update display when count changes ─────────────────────
    if (changed) {
        cli();              // disable interrupts briefly
        uint16_t snap = count;  // take a safe snapshot
        changed = false;
        sei();              // re-enable interrupts

        lcd_setCursor(0, 0);
        lcd_print("Count: ");
        lcd_printInt(snap);
        lcd_print("        ");

        Serial.print("Counter: ");
        Serial.println(snap);
    }
}