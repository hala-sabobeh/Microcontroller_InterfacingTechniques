#include "Timer.h"

// ── LCD driver (RS=D12/PB4, EN=D13/PB5) ─────────────────────────
#define DATA_MASK 0xF0
#define RS_BIT (1<<PB4)
#define EN_BIT (1<<PB5)

void lcd_pulse_en() {
    PORTB |= EN_BIT;
    __asm__ __volatile__("nop\n nop\n nop\n nop\n");
    PORTB &= ~EN_BIT;
}

void lcd_send_nibble(uint8_t nib) {
    PORTD = (PORTD & ~DATA_MASK) | (nib & DATA_MASK);
    lcd_pulse_en();
}

void lcd_send(uint8_t byte, uint8_t rs) {
    if (rs) PORTB |= RS_BIT;
    else    PORTB &= ~RS_BIT;
    lcd_send_nibble(byte & 0xF0);
    lcd_send_nibble((byte << 4) & 0xF0);
    uint32_t t = micros();
    while (micros() - t < 50);
}

void lcd_command(uint8_t cmd) { lcd_send(cmd, 0); }
void lcd_data(uint8_t b)      { lcd_send(b,   1); }

void lcd_setCursor(uint8_t col, uint8_t row) {
    uint8_t addr = (row == 0) ? 0x00 : 0x40;
    lcd_command(0x80 | (addr + col));
}

void lcd_print(const char *s) {
    while (*s) lcd_data(*s++);
}

void lcd_printInt(uint32_t n) {
    char buf[11];
    uint8_t i = 0;
    if (n == 0) { lcd_data('0'); return; }
    while (n > 0) { buf[i++] = '0' + (n % 10); n /= 10; }
    for (int8_t j = i-1; j >= 0; j--) lcd_data(buf[j]);
}

void lcd_init() {
    DDRB |= RS_BIT | EN_BIT;
    DDRD |= DATA_MASK;
    uint32_t t = micros();
    while (micros() - t < 50000);
    PORTB &= ~RS_BIT;
    lcd_send_nibble(0x30);
    t = micros(); while (micros() - t < 4200);
    lcd_send_nibble(0x30);
    t = micros(); while (micros() - t < 150);
    lcd_send_nibble(0x30);
    t = micros(); while (micros() - t < 150);
    lcd_send_nibble(0x20);
    t = micros(); while (micros() - t < 150);
    lcd_command(0x28);
    lcd_command(0x0C);
    lcd_command(0x06);
    PORTB &= ~RS_BIT;
    lcd_send_nibble(0x00 & 0xF0);
    lcd_send_nibble((0x01 << 4) & 0xF0);
    t = micros(); while (micros() - t < 2000);
}

// ── Q3 globals ───────────────────────────────────────────────────
#define LED1_PIN 8
#define LED2_PIN 9
#define BTN_PIN  3   // bonus button on PD3

Timer t1, t2, t3, t4, t5;

volatile int tickCount = 0;
bool pulseActive = false;
uint32_t pulseEndTime = 0;

// ── Bonus globals ─────────────────────────────────────────────────
bool fastMode = false;
uint32_t fastModeEnd = 0;
uint8_t btn_prev = 1;
uint32_t lastBtnPress = 0;

// timer event IDs so we can stop them later
int8_t id3, id4, id5;

void countTick() {
    tickCount++;
}

void triggerPulse() {
    t2.pulse(LED2_PIN, 100, HIGH);
    pulseActive = true;
    pulseEndTime = millis() + 100;
}

void updateLCD() {
    lcd_setCursor(0, 0);
    lcd_print("Ticks: ");
    lcd_printInt(tickCount);
    lcd_print("   ");
    if (!pulseActive) {
        lcd_setCursor(0, 1);
        lcd_print("L1:osc L2:pulse ");
    }
}

// ── setup & loop ─────────────────────────────────────────────────
void setup() {
    // bonus button input with pull-up
    DDRD  &= ~(1<<PD3);
    PORTD |=  (1<<PD3);

    lcd_init();
    lcd_setCursor(0, 1);
    lcd_print("L1:osc L2:pulse ");

    t1.oscillate(LED1_PIN, 400, HIGH);
    id3 = t3.every(2000, triggerPulse);
    id4 = t4.every(1000, countTick);
    id5 = t5.every(500, updateLCD);
}

void loop() {
    t1.update();
    t2.update();
    t3.update();
    t4.update();
    t5.update();

    // millis() flag for "L2:off" for 200ms after pulse ends
    if (pulseActive && millis() >= pulseEndTime) {
        pulseActive = false;
        lcd_setCursor(0, 1);
        lcd_print("L1:osc L2:off   ");
        pulseEndTime = millis() + 200;
    }

    // ── Bonus: button on PD3 halves timer periods for 5s ─────────
    uint8_t btn_now = (PIND >> PD3) & 1;
    if (btn_now == 0 && btn_prev == 1 && (millis() - lastBtnPress >= 50)) {
        lastBtnPress = millis();
        if (!fastMode) {
            fastMode = true;
            fastModeEnd = millis() + 5000;
            // stop current timers and restart at half period
            t3.stop(id3);
            t4.stop(id4);
            t5.stop(id5);
            id3 = t3.every(1000, triggerPulse);  // half of 2000ms
            id4 = t4.every(500, countTick);       // half of 1000ms
            id5 = t5.every(250, updateLCD);       // half of 500ms
        }
    }
    btn_prev = btn_now;

    // restore normal periods after 5 seconds
    if (fastMode && millis() >= fastModeEnd) {
        fastMode = false;
        t3.stop(id3);
        t4.stop(id4);
        t5.stop(id5);
        id3 = t3.every(2000, triggerPulse);
        id4 = t4.every(1000, countTick);
        id5 = t5.every(500, updateLCD);
    }
}