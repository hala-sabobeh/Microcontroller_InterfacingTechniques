void setup() {
    // Set PB0-PB4 as outputs (LED A, B, C, D, E)
    DDRB |= (1<<PB0) | (1<<PB1) | (1<<PB2) | (1<<PB3) | (1<<PB4);
    // Set PD2 as input with internal pull-up
    DDRD  &= ~(1<<PD2);
    PORTD |=  (1<<PD2);
    // LED C starts ON (phase offset)
    PORTB |= (1<<PB2);
    Serial.begin(9600);
}
void loop() {
    uint32_t now = millis();
    // ── LED A: 500ms ──────────────────────────────────────
    static uint32_t prevA = 0;
    if (now - prevA >= 500) {
        prevA = now;
        PORTB ^= (1<<PB0);
    }
    // ── LED B: 300ms ──────────────────────────────────────
    static uint32_t prevB = 0;
    if (now - prevB >= 300) {
        prevB = now;
        PORTB ^= (1<<PB1);
    }
    // ── LED C: 750ms, phase offset 375ms ──────────────────
    static uint32_t prevC = 0;
    static bool cOffsetDone = false;

    if (!cOffsetDone) {
        if (now >= 375) {
            PORTB ^= (1<<PB2);  // first toggle at 375ms
            prevC = now;
            cOffsetDone = true;
        }
    } else {
        if (now - prevC >= 750) {
            prevC = now;
            PORTB ^= (1<<PB2);
        }
    }
    // ── Button -> toggle LED D with 50ms debounce ──────────
    static uint32_t lastPress = 0;
    static uint8_t lastState = 1;
    uint8_t btnState = (PIND >> PD2) & 1;
    if (btnState == 0 && lastState == 1 && (now - lastPress >= 50)) {
        PORTB ^= (1<<PB3);
        lastPress = now;
    }
    lastState = btnState;
    // ── Serial status every 2 seconds ─────────────────────
    static uint32_t prevSerial = -1900UL;
    if (now - prevSerial >= 2000) {
        prevSerial = now;
        Serial.print("A="); Serial.print((PORTB >> PB0) & 1);
        Serial.print(" B="); Serial.print((PORTB >> PB1) & 1);
        Serial.print(" C="); Serial.print((PORTB >> PB2) & 1);
        Serial.print(" D="); Serial.print((PORTB >> PB3) & 1);
      	Serial.print(" E="); Serial.println((PORTB >> PB4) & 1);
    }
    // ── BONUS: LED E ON only when A, B, C all ON ──────────
    if ((PORTB & 0x07) == 0x07)
        PORTB |= (1<<PB4);
    else
        PORTB &= ~(1<<PB4);
}