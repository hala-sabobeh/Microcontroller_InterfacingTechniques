#define DATA_MASK 0xF0   // bits 4-7 of PORTD (where D4-D7 are)
#define RS_BIT (1<<PB0)  // bit 0 of PORTB (D8)
#define EN_BIT (1<<PB1)  // bit 1 of PORTB (D9)


void lcd_pulse_en() {
    PORTB |= EN_BIT;  // EN goes HIGH
    __asm__ __volatile__("nop\n nop\n nop\n nop\n"); // 4 nops = tiny delay (~250ns) so LCD has time to see it
    PORTB &= ~EN_BIT;  // EN goes LOW -> LCD latches the data
}

void lcd_send_nibble(uint8_t nib) {  // sends a full byte as two 4-bit nibbles
    PORTD = (PORTD & ~DATA_MASK) | (nib & DATA_MASK);
    lcd_pulse_en();
}

void lcd_send(uint8_t byte, uint8_t rs) {
    if (rs) PORTB |= RS_BIT;
    else    PORTB &= ~RS_BIT;

    lcd_send_nibble(byte & 0xF0);           // send upper 4 bits first
    lcd_send_nibble((byte << 4) & 0xF0);    // shift lower 4 bits up, send them

    // wait 50µs for LCD to process
    uint32_t t = micros();
    while (micros() - t < 50);
}

// ── public API ───────────────────────────────────────────────────
void lcd_command(uint8_t cmd) { 
  lcd_send(cmd, 0);  // RS=0, command mode
}
void lcd_data(uint8_t b) { 
  lcd_send(b,   1);  // RS=1, data mode
}

// moves the cursor to a position
void lcd_setCursor(uint8_t col, uint8_t row) {
    uint8_t addr = (row == 0) ? 0x00 : 0x40;
    lcd_command(0x80 | (addr + col));
}

// prints a string character by character
void lcd_print(const char *s) {
    while (*s) lcd_data(*s++);
}

// ── init sequence (HD44780 4-bit) ────────────────────────────────
void lcd_init() {
    // set PB0(RS), PB1(EN) as outputs
    DDRB |= RS_BIT | EN_BIT;
    // set PD4-PD7 as outputs, leave PD0-PD3 alone
    DDRD |= DATA_MASK;

    // power-on delay >40 ms
    uint32_t t = micros();
    while (micros() - t < 50000);

    // special 8-bit reset sequence — send nibble 0x30 three times
    PORTB &= ~RS_BIT;
    lcd_send_nibble(0x30);
    t = micros(); while (micros() - t < 4200);   // >4.1 ms

    lcd_send_nibble(0x30);
    t = micros(); while (micros() - t < 150);    // >100 µs

    lcd_send_nibble(0x30);
    t = micros(); while (micros() - t < 150);

    // switch to 4-bit mode
    lcd_send_nibble(0x20);
    t = micros(); while (micros() - t < 150);

    // from here on, full 2-nibble commands
    lcd_command(0x28);  // function set: 4-bit, 2 lines, 5x8 font
    lcd_command(0x0C);  // display ON, cursor OFF, blink OFF
    lcd_command(0x06);  // entry mode: increment, no shift

    // clear display — needs ≥ 1.64 ms wait
    PORTB &= ~RS_BIT;
    lcd_send_nibble(0x00 & 0xF0);
    lcd_send_nibble((0x01 << 4) & 0xF0);
    t = micros(); while (micros() - t < 2000);  // >1.64 ms
}

// ── helper: print an integer ─────────────────────────────────────
// converts a number to characters
void lcd_printInt(uint32_t n) {
    char buf[11];
    uint8_t i = 0;
    if (n == 0) { lcd_data('0'); return; }
    while (n > 0) { buf[i++] = '0' + (n % 10); n /= 10; }
    // reverse
    for (int8_t j = i-1; j >= 0; j--) lcd_data(buf[j]);
}

// ── Arduino entry points ─────────────────────────────────────────
void setup() {
    lcd_init();             // wake up LCD
    lcd_setCursor(0, 0);    // go to row 0, col 0
    lcd_print("Hala 1220322");  
}

void loop() {
    static uint32_t prev = 0;
    static uint32_t seconds = 0;

    uint32_t now = millis();
    if (now - prev >= 1000) {   // every 1 second
        prev = now;
        seconds++;
        lcd_setCursor(0, 1);   // go to row 1
        lcd_print("Time: ");
        lcd_printInt(seconds);  // print the number
        lcd_print("s  ");   // trailing spaces clear old digits
    }
}